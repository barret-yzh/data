package com.ytyn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YtynApplicationTests {

    @Test
    void contextLoads() {
    }

}
