package com.ytyn.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ytyn.dao.entity.NewsCategory;

public interface NewsCategoryMapper extends BaseMapper<NewsCategory> {

}