package com.ytyn.dao.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_news")
public class News implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;// 唯一标识
    private Integer category;// 资讯类别
    private String title;// 资讯标题
    private String content;// 资讯内容
    private String createTime;// 创建时间
    private String updateTime;// 更新时间
    @TableLogic
    private Integer deleted;// 逻辑删除
}
