package com.ytyn.common.exception;

import com.ytyn.common.resp.RestResp;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * 统一处理业务异常
     */
    @ExceptionHandler(BusinessException.class)
    public RestResp<Void> handlerBusinessException(BusinessException e) {
        return RestResp.fail(e.getErrorCodeEnum());
    }

    /**
     * 统一处理空值异常
     */
    @ExceptionHandler(NullException.class)
    public RestResp<Void> handlerNullException(NullException e) {
        return RestResp.fail(e.getErrorCodeEnum());
    }
}