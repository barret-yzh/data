package com.ytyn.common.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCodeEnum {

    OK("200", "一切OK"),
    SERVER_ERROR("500", "服务器异常"),
    USER_REGISTER_NULL_NAME("A0100", "用户注册时，用户名不能为空"),
    USER_REGISTER_NULL_PASSWORD("A0101", "用户注册时，密码不能为空"),
    USER_REGISTER_FAIL("A0102", "用户注册失败，系统已有该用户"),
    USER_LOGIN_NULL_NAME("A0103", "用户登录时，用户名不能为空"),
    USER_LOGIN_NULL_PASSWORD("A0104", "用户登录时，密码不能为空"),
    USER_LOGIN_FAIL("A0105", "用户登录失败，用户名或密码错误"),
    USER_GET_USER_BY_NAME_NULL_NAME("A0106", "用户名不能为空"),
    USER_GET_USER_BY_NAME_FAIL("A0107", "系统不存在该用户");

    /**
     * 错误码
     */
    private final String code;

    /**
     * 中文描述
     */
    private final String message;
}
