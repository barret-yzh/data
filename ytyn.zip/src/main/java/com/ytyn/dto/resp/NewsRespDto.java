package com.ytyn.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsRespDto {

    private String category;// 资讯类别
    private String title;// 资讯标题
    private String content;// 资讯内容
}
