package com.ytyn.controller;

import com.ytyn.common.resp.RestResp;
import com.ytyn.dao.entity.User;
import com.ytyn.dto.req.UserRegisterReqDto;
import com.ytyn.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("user")
@CrossOrigin
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("register")
    public RestResp<User> register(UserRegisterReqDto userRegisterReqDto) {
        return userService.register(userRegisterReqDto);
    }

    @GetMapping("login")
    public RestResp<User> login(@RequestParam("userName") String userName, @RequestParam("password") String password) {
        return userService.login(userName, password);
    }

    @GetMapping("selectUsers")
    public RestResp<List<User>> selectUsers() {
        return userService.selectUsers();
    }

    @GetMapping("getUserByUserName")
    public RestResp<User> getUserByUserName(@RequestParam("userName") String userName) {
        return userService.getUserByName(userName);
    }

    @RequestMapping("deleteUser")
    public RestResp<User> deleteUser(@RequestParam("id") Long id) {
        return userService.deleteUser(id);
    }
}
