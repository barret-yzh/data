package com.ytyn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ytyn.common.resp.RestResp;
import com.ytyn.dao.entity.News;
import com.ytyn.dto.resp.NewsRespDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface NewsService extends IService<News> {

    RestResp<List<NewsRespDto>> selectNews();

//    RestResp<News> addNews(@Param("news") News news);
//
//    RestResp<News> updateNews(@Param("news") News news);
//
//    RestResp<News> deleteNews(@Param("id") Long id);
//
//    RestResp<List<News>> getNewsByTitleLike(@Param("title") String title);
}
