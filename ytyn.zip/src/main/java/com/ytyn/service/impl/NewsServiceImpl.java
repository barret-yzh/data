package com.ytyn.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ytyn.common.resp.RestResp;
import com.ytyn.dao.entity.News;
import com.ytyn.dao.mapper.NewsMapper;
import com.ytyn.dto.resp.NewsRespDto;
import com.ytyn.service.NewsCategoryService;
import com.ytyn.service.NewsService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class NewsServiceImpl extends ServiceImpl<NewsMapper, News> implements NewsService {

    @Autowired
    private NewsMapper newsMapper;

    @Autowired
    private NewsCategoryService newsCategoryService;

    @Override
    public RestResp<List<NewsRespDto>> selectNews() {
        List<News> newsList = newsMapper.selectList(null);
        List<NewsRespDto> newsRespDtoList = new ArrayList<>();
        for (News news : newsList) {
            NewsRespDto newsRespDto = new NewsRespDto();
            BeanUtils.copyProperties(news, newsRespDto);
            newsRespDto.setCategory(newsCategoryService.getById(news.getCategory()).getName());
            newsRespDtoList.add(newsRespDto);
        }
        return RestResp.ok(newsRespDtoList);
    }

//    @Override
//    public News addNews(News news) {
//        if (news.getTitle() == null || news.getTitle().trim().equals("") || news.getContent() == null || news.getContent().trim().equals("")) {
//            NullException.throwNullException(5019, "添加资讯时，标题或内容不能为空");
//        }
//        news.setCreateTime(DateUtil.dateTimeFormatter());
//        news.setUpdateTime(DateUtil.dateTimeFormatter());
//        if (newsMapper.insert(news) != 1) {
//            throw new RuntimeException("未知原因，添加资讯失败");
//        }
//        return news;
//    }
//
//    @Override
//    public News updateNews(News news) {
//        if (news.getTitle().trim().equals("") || news.getContent().trim().equals("")) {
//            NullException.throwNullException(5020, "修改资讯时，标题或内容不能为空");
//        }
//        news.setUpdateTime(DateUtil.dateTimeFormatter());
//        if (newsMapper.updateById(news) != 1) {
//            throw new RuntimeException("未知原因，修改资讯失败");
//        }
//        return news;
//    }
//
//    @Override
//    public News deleteNews(Long id) {
//        if (id == null) {
//            NullException.throwNullException(5021, "删除资讯时，id不能为空");
//        }
//        News news = newsMapper.selectById(id);
//        if (newsMapper.deleteById(id) != 1) {
//            throw new RuntimeException("未知原因，删除资讯失败");
//        }
//        return news;
//    }
//
//    @Override
//    public List<News> getNewsByTitleLike(String title) {
//        if (title.trim().equals("")) {
//            NullException.throwNullException(5022, "模糊查询资讯标题时，标题不能为空");
//        }
//        QueryWrapper<News> queryWrapper = new QueryWrapper<>();
//        queryWrapper.like("title", title);
//        return newsMapper.selectList(queryWrapper);
//    }
}
