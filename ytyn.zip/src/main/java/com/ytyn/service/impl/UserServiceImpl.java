package com.ytyn.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ytyn.common.constant.ErrorCodeEnum;
import com.ytyn.common.exception.BusinessException;
import com.ytyn.common.resp.RestResp;
import com.ytyn.dao.entity.User;
import com.ytyn.common.exception.NullException;
import com.ytyn.dao.mapper.UserMapper;
import com.ytyn.dto.req.UserRegisterReqDto;
import com.ytyn.service.UserService;
import com.ytyn.common.util.DateUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public RestResp<User> register(UserRegisterReqDto userDto) {
        if (userDto.getUserName() == null || userDto.getUserName().trim().equals(""))
            throw new NullException(ErrorCodeEnum.USER_REGISTER_NULL_NAME);
        if (userDto.getPassword() == null || userDto.getPassword().trim().equals(""))
            throw new NullException(ErrorCodeEnum.USER_REGISTER_NULL_PASSWORD);
        String userName = userDto.getUserName();
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_name", userName);
        User result = userMapper.selectOne(queryWrapper);
        if (result != null) {
            throw new BusinessException(ErrorCodeEnum.USER_REGISTER_FAIL);
        }
        User user = new User();
        BeanUtils.copyProperties(userDto, user);
        user.setCreateTime(DateUtil.dateTimeFormatter());
        user.setUpdateTime(DateUtil.dateTimeFormatter());
        if (userMapper.insert(user) != 1) {
            throw new BusinessException(ErrorCodeEnum.SERVER_ERROR);
        }
        return RestResp.ok(user);
    }

    @Override
    public RestResp<User> login(String userName, String password) {
        if (userName == null || userName.trim().equals("")) {
            throw new NullException(ErrorCodeEnum.USER_LOGIN_NULL_NAME);
        }
        if (password == null || password.trim().equals("")) {
            throw new NullException(ErrorCodeEnum.USER_LOGIN_NULL_PASSWORD);
        }
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_name", userName);
        queryWrapper.eq("password", password);
        User user = userMapper.selectOne(queryWrapper);
        if (user == null) {
            throw new BusinessException(ErrorCodeEnum.USER_LOGIN_FAIL);
        }
        return RestResp.ok(user);
    }

    @Override
    public RestResp<List<User>> selectUsers() {
        return RestResp.ok(userMapper.selectList(null));
    }

    @Override
    public RestResp<User> getUserByName(String userName) {
        if (userName == null || userName.trim().equals("")) {
            throw new NullException(ErrorCodeEnum.USER_GET_USER_BY_NAME_NULL_NAME);
        }
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_name", userName);
        User user = userMapper.selectOne(queryWrapper);
        if (user == null) {
            throw new BusinessException(ErrorCodeEnum.USER_GET_USER_BY_NAME_FAIL);
        }
        return RestResp.ok(user);
    }

    @Override
    public RestResp<User> deleteUser(Long id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException(ErrorCodeEnum.USER_GET_USER_BY_NAME_FAIL);
        }
        if (userMapper.deleteById(id) != 1) {
            throw new BusinessException(ErrorCodeEnum.SERVER_ERROR);
        }
        return RestResp.ok(user);
    }
}
