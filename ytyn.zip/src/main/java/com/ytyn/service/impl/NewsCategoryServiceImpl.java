package com.ytyn.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ytyn.dao.entity.NewsCategory;
import com.ytyn.dao.mapper.NewsCategoryMapper;
import com.ytyn.dao.mapper.NewsMapper;
import com.ytyn.service.NewsCategoryService;
import org.springframework.stereotype.Service;

@Service
public class NewsCategoryServiceImpl extends ServiceImpl<NewsCategoryMapper, NewsCategory> implements NewsCategoryService {
}
