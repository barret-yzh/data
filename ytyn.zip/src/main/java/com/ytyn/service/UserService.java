package com.ytyn.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ytyn.common.resp.RestResp;
import com.ytyn.dao.entity.User;
import com.ytyn.dto.req.UserRegisterReqDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserService extends IService<User> {

    RestResp<User> register(@Param("userDto") UserRegisterReqDto userDto);

    RestResp<User> login(@Param("userName") String userName, @Param("password") String password);

    RestResp<List<User>> selectUsers();

    RestResp<User> getUserByName(@Param("userName") String userName);

    RestResp<User> deleteUser(@Param("id") Long id);
}
