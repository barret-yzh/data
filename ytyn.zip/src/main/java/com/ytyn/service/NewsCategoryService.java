package com.ytyn.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.ytyn.dao.entity.NewsCategory;

public interface NewsCategoryService extends IService<NewsCategory> {

}
