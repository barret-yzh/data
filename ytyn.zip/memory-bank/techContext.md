# 技术上下文：计算机考研信息平台

## 技术栈清单
### 后端技术
- **核心框架**：Spring Boot 3.4.2
- **ORM框架**：MyBatis-Plus 3.5.2
- **数据库**：MySQL 8.0
- **连接池**：HikariCP 4.0.3
- **API文档**：Swagger 2.7.0
- **开发工具**：Lombok

### 开发环境
- **JDK版本**：Java 17
- **构建工具**：Maven
- **IDE**：IntelliJ IDEA
- **版本控制**：Git

### 部署环境
- **服务器端口**：8010
- **应用上下文路径**：/ytyn
- **部署方式**：未确定，可能是传统部署或Docker容器

## 技术约束
1. **API设计**：遵循RESTful设计规范
2. **数据库操作**：统一使用MyBatis-Plus进行CRUD操作
3. **逻辑删除**：所有实体类采用逻辑删除机制
4. **统一响应**：所有接口使用ResultDto包装返回结果
5. **文件上传**：最大单文件限制10MB，总请求大小限制100MB

## 外部依赖
1. **MySQL数据库**：需要本地安装MySQL 8.0版本
2. **文件存储**：本地文件系统（未见云存储服务集成）
3. **AI服务**：预期将集成第三方AI服务或自建模型服务（待实现）

## 开发配置说明
```properties
# 数据库配置
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/ytyn?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=123456

# MyBatis-Plus配置
mybatis-plus.configuration.log-impl=org.apache.ibatis.logging.stdout.StdOutImpl
mybatis-plus.global-config.db-config.logic-delete-field=deleted
mybatis-plus.global-config.db-config.logic-delete-value=1
mybatis-plus.global-config.db-config.logic-not-delete-value=0

# 文件上传配置
spring.servlet.multipart.max-request-size=100MB
spring.servlet.multipart.max-file-size=10MB
```

## 数据库结构
根据实体类推测数据库包含以下主要表：
1. **t_user**：用户表
2. **t_school**：学校表
3. **t_major**：专业表
4. **t_datum**：资料表
5. **t_datum_type**：资料类型表
6. **t_news**：资讯表 